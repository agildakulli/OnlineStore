package com.example.demo.mapper;

import com.example.demo.dto.OrderDto;
import com.example.demo.entity.Order;

public class OrderMapper {
    public Order mapToEntity(OrderDto orderDto){
        Order order=new Order();
        order.setId(orderDto.getId());
        order.setProducts(orderDto.getUser().getProducts());
        order.setTotalCost(orderDto.getTotalCost());
        order.setDateOfSubmission(orderDto.getDateOfSubmission());
        order.setDeliveryAddress(orderDto.getDeliveryAddress());
        order.setUser(orderDto.getUser());
        return order;

    }
    public OrderDto mapToDto(Order order){
        OrderDto orderDto= new OrderDto();
        orderDto.setUser(order.getUser());
        orderDto.setId(order.getId());
        orderDto.setTotalCost(order.getTotalCost());
        orderDto.setDateOfSubmission(order.getDateOfSubmission());
        orderDto.setDeliveryAddress(order.getDeliveryAddress());

        return orderDto;
    }
}

