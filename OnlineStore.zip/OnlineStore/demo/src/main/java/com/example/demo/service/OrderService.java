package com.example.demo.service;

import com.example.demo.entity.Order;
import com.example.demo.respository.OrderRespository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Service
public class OrderService {

    private final OrderRespository orderRepository;

    @Autowired
    public OrderService(OrderRespository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public Order saveOrder(Order order) {
        return orderRepository.save(order);
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Optional<Order> getOrderById(Long orderId) {
        return orderRepository.findById(orderId);
    }

    public Order updateOrder(Long orderId, Order updatedOrder) {
        Optional<Order> existingOrder = orderRepository.findById(orderId);

        existingOrder.ifPresent(order -> {
            order.setTotalCost(updatedOrder.getTotalCost());
            order.setDeliveryAddress(updatedOrder.getDeliveryAddress());
            order.setDateOfSubmission(updatedOrder.getDateOfSubmission());
            order.setStatus(updatedOrder.getStatus());



            orderRepository.save(order);
        });

        return existingOrder.orElse(null);
    }

    public void deleteOrder(Long orderId) {
        orderRepository.deleteById(orderId);
    }
}



